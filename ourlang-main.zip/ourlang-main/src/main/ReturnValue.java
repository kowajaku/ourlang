package main;

public class ReturnValue extends RuntimeException {
	public ourlangValue value;
}
